

import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;
import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
	private boolean[] openSite; // if open is 1 , block 0
	private int N; // create N-by-N grid
	private WeightedQuickUnionUF uf;
	private int top;
	private int bottom;
	private int numberOfOpenSites;

	public Percolation(int n) { // create N-by-N grid, with all sites blocked
		if (n <= 0) {
			throw new IllegalArgumentException("N must be bigger than 0");
		}
		this.N = n;
		uf = new WeightedQuickUnionUF(N * N + 2);
		openSite = new boolean[N * N + 2]; // 0 top_visual N*N+1 bottom_visual
		top = 0;
		bottom = N * N + 1;
		
	}

	public int numberOfOpenSites() {
		return numberOfOpenSites;
	}

	public void open(int i, int j) { // open site (row i, column j) if it is not open already
		validateIJ(i, j);
		int index = getIndex(i, j);
		openSite[index] = true;
		numberOfOpenSites++;
		if (i == 1) {
			uf.union(index, top);
		}
		if (!percolates()) {
			if (i == N) {
				uf.union(index, bottom);
			}
		}
		if (i < N && openSite[index + N]) {
			uf.union(index, index + N);
		}
		if (i > 1 && openSite[index - N]) {
			uf.union(index, index - N);
		}
		if (j < N && openSite[index + 1]) {
			uf.union(index, index + 1);
		}
		if (j > 1 && openSite[index - 1]) {
			uf.union(index, index - 1);
		}

	}

	private int getIndex(int i, int j) {
		validateIJ(i, j);
		return j + (i - 1) * N;
	}

	private void validateIJ(int i, int j) {
		if (!(i >= 1 && i <= N && j >= 1 && j <= N)) {
			throw new IndexOutOfBoundsException("Index is not betwwen 1 and N");
		}
	}

	public boolean isOpen(int i, int j) { // is site (row i, column j) open?
		validateIJ(i, j);
		return openSite[getIndex(i, j)];
	}

	/*
	 * A full site is an open site that can be connected to an open site in the top
	 * row via a chain of neighboring (left, right, up, down) open sites.
	 */
	public boolean isFull(int i, int j) { // is site (row i, column j) full?
		validateIJ(i, j);
		return uf.connected(top, getIndex(i, j));
	}

	/*
	 * Introduce 2 virtual sites (and connections to top and bottom). Percolates iff
	 * virtual top site is connected to virtual bottom site.
	 */
	public boolean percolates() { // does the system percolate?
		return uf.connected(top, bottom);
	}

	public static void main(String[] args) {

		Percolation percolation = new Percolation(1);
		System.out.println(percolation.percolates());
		percolation.open(1, 1);
		System.out.println(percolation.percolates());
		Percolation percolation2 = new Percolation(2);
		System.out.println(percolation2.percolates());
		percolation2.open(1, 1);
		System.out.println(percolation2.percolates());
		percolation2.open(2, 1);
		System.out.println(percolation2.percolates());
		// test client (optional)
	}
//
//	boolean isOpen[];
//	int gridLength;
//	WeightedQuickUnionUF weigtedQuickFindUF;
//	int numberOfOpenSites;
//
//	// creates n-by-n grid, with all sites initially blocked
//	public Percolation(int n) {
//		if (n <= 0) {
//			throw new IllegalArgumentException();
//		}
//		gridLength = n;
//		isOpen = new boolean[n * n];
//
//		weigtedQuickFindUF = new WeightedQuickUnionUF(n * n + 2);
//	}
//
//	// opens the site (row, col) if it is not open already
//	public void open(int i, int j) {
////		int size = isOpen.length;
////		int index = i * gridLength + j;
////		if (i < 0 || i >= size) {
////			return;
////		}
////		if (j < 0 || j >= size) {
////			return;
////		}
////		if (index < 0 || index >= size) {
////			return;
////		}
////		if (isFull(i, j)) {
////			return;
////		}
////		if (!isOpen(i, j)) {
////			isOpen[index] = true;
//////			weigtedQuickFindUF.connected(i, j);
////			weigtedQuickFindUF.union(i, ind);
//		
//	if (column + 1 < size) {      //go to next column
//	    open(j + 1, i);
//	} else if (j + 1 == isOpen.length && i + 1 < isOpen.length) {  //go to next row 
//		open(0, i + 1, open, ufid + 1);
//	} else {
//	    return;
//	
//		
//////		
////		  int pos = (i * gridLength) + j;
////		     
////		     if (!isOpen(i, j)) {
////		       isOpen[pos] = true;
////		       
////		       // check for open adjacent grid positions;
////		       if (i > 0) { // row above
////		         if (isOpen(i-1, j)) {
////		        	 weigtedQuickFindUF.union(pos + 1, pos-gridLength + 1);
////		         }
////		       } else { // on the top we union with the top virtual element
////		         weigtedQuickFindUF.union(0, pos + 1);
////		       }
////		       
////		       if (i < gridLength-1) { // row below
////		         if (isOpen(i+1, j)) {
////		        	 weigtedQuickFindUF.union(pos + 1, pos+gridLength + 1);
////		         }
////		       } else { // on the bottom, we union with the bottom virtual element
////		    	   weigtedQuickFindUF.union(gridLength*gridLength+1, pos+1);
////		       }
////		       
////		       if (j > 0 && isOpen(i, j-1)) { // column to the left
////		    	   weigtedQuickFindUF.union(pos + 1, pos-1 + 1);
////		       }
////		       
////		       if (j < gridLength-1 && isOpen(i, j+1)) { // column to the right
////		    	   weigtedQuickFindUF.union(pos + 1, pos+1 + 1);
////		       }
////		     }
//	}
////		int n = isOpen.length;
////	  int pos = (i * gridLength +j);
////        // base cases
////        if (i < 0 || i >= n) return;    // invalid row
////        if (j < 0 || j >= n) return;
////        if (pos<0 || pos>=n) {
////			return;
////		}// invalid column
////        if (!isOpen(i,j)) {
////        	isOpen[pos]= true;
////        }
////        if (isFull(i,j) )return; 
////
////        open(  i+1, j);   // down
////        open( i, j+1);   // right
////        open( i, j-1);   // left
////        open(i-1, j);   //
////	}
//
////	private int checkSite(int i, int j) {
////		checkBounds(i, j);
////		return (i - 1) *gridLength + (j);
////	}
////	private void checkBounds(int i, int j) {
////		if (i > isOpen.length || i < 1) {
////			throw new IndexOutOfBoundsException("row index i out of bounds");
////		}
////		if (j > isOpen.length || j < 1) {
////			throw new IndexOutOfBoundsException("column index j out of bounds");
////		}
////	}
//	// is the site (row, col) open?
//	public boolean isOpen(int row, int col) {
//		int index = row * gridLength + col;
//		return isOpen[index];
////		if (row >= isOpen.length || row < 0) {
////			throw new IllegalArgumentException();
////
////		}
////		if (col >= isOpen.length || col < 0) {
////			throw new IllegalArgumentException();
////
////		}
////		int site = checkSite(row, col);
////		return isOpen[site];
////	
//	}
//
//	// is the site (row, col) full?
//	public boolean isFull(int row, int col) {
////		if (row >=isOpen.length || row < 0) {
////			throw new IllegalArgumentException();
////
////		}
////		if (col >= isOpen.length|| col < 0) {
////			throw new IllegalArgumentException();
////
////		}
////		for (int i = 0; i < isOpen.length; i++) {
////			int site = checkSite(row, col);
////			if (!isOpen[site]) {
////				return false;
////			}
////			
////		}
//		int index = row * gridLength + col;
//		return isOpen[index];
////		
////		return true;
////
//
//	}
//
//	// returns the number of open sites
//	public int numberOfOpenSites() {
//		return numberOfOpenSites;
//
//	}
//
//	// does the system percolate?
//	public boolean percolates() {
//		return weigtedQuickFindUF.connected(0, gridLength * gridLength + 1);
//	}
//
//	// test client (optional)

}