
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.Stack;

import edu.princeton.cs.algs4.StdOut;

public final class Board {

	private final int size;
	private final List<List<Integer>> lists;
	private List<Integer> list;

	// create a board from an n-by-n array of tiles,
	// where tiles[row][col] = tile at (row, col)
	public Board(int[][] tiles) {
		lists = new ArrayList<List<Integer>>(tiles.length);
		list = new ArrayList<>(tiles[0].length);
		size = tiles.length;
		for (int i = 0; i < tiles.length; i++) {
			list = new ArrayList<>();
			for (int j = 0; j < tiles.length; j++) {
				list.add(tiles[i][j]);
				Collections.unmodifiableList(list);

			}

			lists.add(list);

		}

	}

	// board dimension n

	private int manhattanDistance(int i, int j, int square) {
		square--;
		int horizontal = Math.abs(square % dimension() - j);
		int vertical = Math.abs(square / dimension() - i);
		return horizontal + vertical;
	}

	// is this board the goal board?
	public boolean isGoal() {
		return hamming() == 0;
	}

	// does this board equal y?
	public boolean equals(Object y) {
		if (y == null) {
			return false;
		}
		if (!(y instanceof Board)) {
			return false;
		}
		Board boards = (Board) y;
		return boards.lists.equals(lists);
	}

	// all neighboring boards
	public Iterable<Board> neighbors() {
		Stack<Board> boardStack = new Stack<>();
		for (int i = 0; i < lists.size(); i++) {
//			List<Integer> newList =out.get(i);
			for (int j = 0; j < lists.get(i).size(); j++) {
				// we have found 0 block
				if (lists.get(i).get(j) == Integer.valueOf(0)) {

					// if 0 block is not at top position
					if (i > 0) {
						int[][] blocksCopy = copyBlocks(lists, size);
						blocksCopy[i][j] = lists.get(i - 1).get(j).intValue();
						blocksCopy[i - 1][j] = lists.get(i).get(j).intValue();
						boardStack.push(new Board(blocksCopy));
					}

					// if 0 block is not at left position
					if (j > 0) {
						int[][] blocksCopy = copyBlocks(lists, size);
						blocksCopy[i][j] = lists.get(i).get(j - 1).intValue();
						blocksCopy[i][j - 1] = lists.get(i).get(j).intValue();
						boardStack.push(new Board(blocksCopy));
					}

					// if 0 block is not at bottom position
					if (i < size - 1) {
						int[][] blocksCopy = copyBlocks(lists, size);
						blocksCopy[i][j] = lists.get(i + 1).get(j).intValue();
						blocksCopy[i + 1][j] = lists.get(i).get(j).intValue();
						boardStack.push(new Board(blocksCopy));
					}

					// if 0 block is not at right position
					if (j < size - 1) {
						int[][] blocksCopy = copyBlocks(lists, size);
						blocksCopy[i][j] = lists.get(i).get(j + 1).intValue();
						blocksCopy[i][j + 1] = lists.get(i).get(j).intValue();
						boardStack.push(new Board(blocksCopy));
					}

					break;
				}
			}
		}

		return boardStack;
	}

	private int[][] copyBlocks(List<List<Integer>> lists, int dimensionSize) {
		int[][] result = new int[lists.size()][lists.get(0).size()];
		for (int i = 0; i < dimensionSize; i++) {
			for (int j = 0; j < dimensionSize; j++) {
//				result[i][j] = list.get(j);
				result[i][j] = lists.get(i).get(j).intValue();
			}
		}

		return result;
	}

	// a board that is obtained by exchanging any pair of tiles

	private int[][] swap(int i1, int j1, int i2, int j2) {
		int[][] copy = copy(lists);
		int temp = copy[i1][j1];
		copy[i1][j1] = copy[i2][j2];
		copy[i2][j2] = temp;
		return copy;
	}

	private int[][] copy(List<List<Integer>> lists) {
		int[][] copy = new int[lists.size()][lists.get(0).size()];
		for (int i = 0; i < copy.length; i++) {
			for (int j = 0; j < list.size(); j++) {
				copy[i][j] = lists.get(i).get(j).intValue();
			}
		}
		return copy;
	}

	public Board twin() {
		int[][] twinTiles = copy(lists);

		if (twinTiles[0][0] != 0 && twinTiles[0][1] != 0)
			return new Board(swap(0, 0, 0, 1));
		else
			return new Board(swap(1, 0, 1, 1));
	}

	public String toString() {
		String string = size + "\n";
		for (int i = 0; i < lists.size(); i++) {
			for (int j = 0; j < list.size(); j++) {
				string += list.get(j) + "  ";
			}
			string += "\n";

		}

		return string;
	}

	public int dimension() {
		return size;

	}

	// number of tiles out of place
	public int hamming() {
		int sum = 0;
		int k = 1;
		for (int i = 0; i < lists.size(); i++) {
			for (int j = 0; j < list.size(); j++) {
				if (list.get(j) != k) {
					sum++;
				}
				k++;
				if (k == lists.size() * list.size() - 1) {
					k = 0;
				}
			}

		}

		return sum;

	}

	// sum of Manhattan distances between tiles and goal
	public int manhattan() {
		int manhattan = 0;

		for (int i = 0; i < lists.size(); i++) {
			List<Integer> list = lists.get(i);
			for (int j = 0; j < lists.get(i).size(); j++)
				if (list.get(j) != 0 && list.get(j) != j + i * dimension() + 1)
					manhattan += manhattanDistance(i, j, list.get(j));
		}
		return manhattan;

	}

	// unit testing (notgraded)
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int N = scanner.nextInt();
		int[][] blocks = new int[N][N];
		for (int i = 0; i < blocks.length; i++) {
			for (int j = 0; j < blocks[i].length; j++) {
				blocks[i][j] = scanner.nextInt();
			}
		}
//		blocks[0][0] = 2;
//		blocks[0][1] = 0;
//		blocks[1][0] = 1;
//		blocks[1][1] = 3;
//		blocks[1][1] = 0;
//		blocks[1][2] = 2;
//		blocks[2][0] = 7;
//		blocks[2][1] = 6;
//		blocks[2][2] = 5;

		// for (int i = 0; i < blocks.length; ++i) {
		// for (int j = 0; j < blocks[i].length; ++j) {
		// blocks[i][j] = N * i + j;
		// }
		// }

		Board b = new Board(blocks);
//		Iterable<Board> iterator = b.neighbors();
//		while (iterator.iterator().hasNext()) {
//			Board board = iterator.iterator().next();
//			System.out.println(board.toString());
//
//		}

		StdOut.println(b + "\nhamming : " + b.hamming() + "\nmanhattan: " + b.manhattan());
//		for (int i = 0; i < blocks.length; i++) {
//			b.tiles [0][1] = 2;
//		}
		StdOut.println(b.twin().toString());
		scanner.close();
//		In in = new In(args[0]);
//		int n = in.readInt();
//		int[][] tiles = new int[n][n];
//		for (int i = 0; i < n; i++)
//			for (int j = 0; j < n; j++)
//				tiles[i][j] = in.readInt();
//		Board initial = new Board(tiles);
//
//		// solve the puzzle
		Solver solver = new Solver(b);

		// print solution to standard output
		if (!solver.isSolvable())
			StdOut.println("No solution possible");
		else {
			int count = 0;
			StdOut.println("Minimum number of moves = " + solver.moves());
			for (Board board : solver.solution()) {
				count++;
				StdOut.println(board);
			}
//		}
			System.out.println("count =" + count);
		}

	}
}
