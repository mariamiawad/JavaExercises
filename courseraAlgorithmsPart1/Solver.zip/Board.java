
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.Stack;

import edu.princeton.cs.algs4.StdOut;

public final class Board {

	private final int[] board;
	private final int size;
	private final int[] goalDown;
	private final List<List<Integer>> lists;
	private List<Integer> list;
	private final List<List<Integer>> out;

	// create a board from an n-by-n array of tiles,
	// where tiles[row][col] = tile at (row, col)
	public Board(int[][] tiles) {
		board = new int[tiles.length * tiles[0].length];
		lists = new ArrayList<List<Integer>>();
		list = new ArrayList<>();
		size = tiles.length;
		goalDown = new int[board.length];
		int k = 0;
		for (int i = 0; i < tiles.length; i++) {
			list = new ArrayList<>();
			for (int j = 0; j < tiles.length; j++) {
				list.add(tiles[i][j]);
				board[k] = tiles[i][j];
				k++;

			}

			lists.add(list);

		}
		for (int i = 0; i < goalDown.length; i++) {
			goalDown[i] = i + 1;
			if (i == goalDown.length - 1) {
				goalDown[i] = 0;
			}
		}
		List<List<Integer>> temp = new ArrayList<List<Integer>>();
		for (List<Integer> list : lists) {
			temp.add(Collections.unmodifiableList(list));
		}
		out = Collections.unmodifiableList(temp);

	}

	// board dimension n

	private Board getGoal(int size) {
		int value = 0;
		int[][] goal = new int[size][size];
		for (int i = 0; i < goal.length; i++) {
			for (int j = 0; j < goal[i].length; j++) {
				value++;
				if ((j + 1 == size) && (i + 1 == size)) {
					goal[i][j] = 0;
				} else {
					goal[i][j] = value;
				}

			}

		}
		return new Board(goal);
	}

	private int getCol(int value, List<List<Integer>> lists) {

		for (int i = 0; i < lists.size(); i++) {
			List<Integer> list = lists.get(i);
			for (int j = 0; j < list.size(); j++) {
				if (list.get(j) == value) {
					return j;
				}
			}

		}
		return -1;

	}

	private int manhattanDistance(int i, int j, int square) {
		square--;
		int horizontal = Math.abs(square % dimension() - j);
		int vertical = Math.abs(square / dimension() - i);
		return horizontal + vertical;
	}

	private int getRow(int value, List<List<Integer>> lists) {
		for (int i = 0; i < lists.size(); i++) {
			List<Integer> list = lists.get(i);
			for (int j = 0; j < list.size(); j++) {
				if (list.get(j) == value) {
					return i;
				}
			}

		}
		return -1;

	}

	// is this board the goal board?
	public boolean isGoal() {
		return hamming() == 0;
	}

	// does this board equal y?
	public boolean equals(Object y) {
		if (y == null) {
			return false;
		}
		if (!(y instanceof Board)) {
			return false;
		}
		Board boards = (Board) y;
		return Arrays.equals(boards.board, board);
	}

	// all neighboring boards
	public Iterable<Board> neighbors() {
		Stack<Board> boardStack = new Stack<>();
		Integer[][] tiles = out.stream() .map(l -> l.stream().toArray(Integer[]::new)).toArray(Integer[][]::new);
		for (int i = 0; i < out.size(); i++) {
			List<Integer> newList =out.get(i);
			for (int j = 0; j < newList.size(); j++) {
				// we have found 0 block
				if (newList.get(j) == 0) {

					// if 0 block is not at top position
					if (i > 0) {
						int[][] blocksCopy = copyBlocks(out, size);
						blocksCopy[i][j] = tiles[i - 1][j];
						blocksCopy[i - 1][j] = tiles[i][j];
						boardStack.push(new Board(blocksCopy));
					}

					// if 0 block is not at left position
					if (j > 0) {
						int[][] blocksCopy = copyBlocks(out, size);
						blocksCopy[i][j] = tiles[i][j - 1];
						blocksCopy[i][j - 1] = tiles[i][j];
						boardStack.push(new Board(blocksCopy));
					}

					// if 0 block is not at bottom position
					if (i < size - 1) {
						int[][] blocksCopy = copyBlocks(out, size);
						blocksCopy[i][j] = tiles[i + 1][j];
						blocksCopy[i + 1][j] = tiles[i][j];
						boardStack.push(new Board(blocksCopy));
					}

					// if 0 block is not at right position
					if (j < size - 1) {
						int[][] blocksCopy = copyBlocks(out, size);
						blocksCopy[i][j] = tiles[i][j + 1];
						blocksCopy[i][j + 1] = tiles[i][j];
						boardStack.push(new Board(blocksCopy));
					}

					break;
				}
			}
		}

		return boardStack;
	}

	private int[][] copyBlocks(List<List<Integer>> lists, int dimensionSize) {
		int[][] result = new int[dimensionSize][dimensionSize];

		for (int i = 0; i < dimensionSize; i++) {
			List<Integer> list = lists.get(i);
			for (int j = 0; j < dimensionSize; j++) {
				result[i][j] = list.get(j);
			}
		}

		return result;
	}

	// a board that is obtained by exchanging any pair of tiles

	private int[][] swap(int i1, int j1, int i2, int j2) {
		int[][] copy = copy(out);
		int temp = copy[i1][j1];
		copy[i1][j1] = copy[i2][j2];
		copy[i2][j2] = temp;
		return copy;
	}

	private int[][] copy(List<List<Integer>> blocks) {
		int[][] copy = new int[blocks.size()][blocks.size()];
		for (int i = 0; i < blocks.size(); i++) {
			List<Integer> list = out.get(i);
			for (int j = 0; j < list.size(); j++) {
				copy[i][j] = list.get(j);
			}
		}
		return copy;
	}

	public Board twin() {
		int[][] twinTiles = copy(out);

		if (twinTiles[0][0] != 0 && twinTiles[0][1] != 0)
			return new Board(swap(0, 0, 0, 1));
		else
			return new Board(swap(1, 0, 1, 1));
	}

	public String toString() {
		String string = size + "\n";
		int k = 0;
		for (int i = 0; i < board.length; i++) {
			string += board[i] + "  ";

			k++;
			if (k % size == 0 && k != 0) {
				k = 0;
				string += "\n";
			}

		}

		return string;
	}

	public int dimension() {
		return size;

	}

	// number of tiles out of place
	public int hamming() {
		int sum = 0;
		int k = 1;
		if (Arrays.equals(board, goalDown)) {
			return 0;
		}
		for (int j = 0; j < board.length; j++) {
			if (board[j] != k) {
				sum += 1;

			}
			if (board[j] == 0) {
				sum--;
			}
			k++;

		}
		return sum;
	}

	// sum of Manhattan distances between tiles and goal
	public int manhattan() {
		int manhattan = 0;

		for (int i = 0; i < out.size(); i++) {
			List<Integer> list = out.get(i);
			for (int j = 0; j < list.size(); j++)
				if (list.get(j) != 0 && list.get(j) != j + i * dimension() + 1)
					manhattan += manhattanDistance(i, j, list.get(j));
		}
		return manhattan;

	}

	// unit testing (notgraded)
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int N = scanner.nextInt();
		int[][] blocks = new int[N][N];
		for (int i = 0; i < blocks.length; i++) {
			for (int j = 0; j < blocks[i].length; j++) {
				blocks[i][j] = scanner.nextInt();
			}
		}
//		blocks[0][0] = 2;
//		blocks[0][1] = 0;
//		blocks[1][0] = 1;
//		blocks[1][1] = 3;
//		blocks[1][1] = 0;
//		blocks[1][2] = 2;
//		blocks[2][0] = 7;
//		blocks[2][1] = 6;
//		blocks[2][2] = 5;

		// for (int i = 0; i < blocks.length; ++i) {
		// for (int j = 0; j < blocks[i].length; ++j) {
		// blocks[i][j] = N * i + j;
		// }
		// }

		Board b = new Board(blocks);
//		Iterable<Board> iterator = b.neighbors();
//		while (iterator.iterator().hasNext()) {
//			Board board = iterator.iterator().next();
//			System.out.println(board.toString());
//
//		}

		StdOut.println(b + "\nhamming : " + b.hamming() + "\nmanhattan: " + b.manhattan());
//		for (int i = 0; i < blocks.length; i++) {
//			b.tiles [0][1] = 2;
//		}
		StdOut.println(b.twin().toString());
		scanner.close();
//		In in = new In(args[0]);
//		int n = in.readInt();
//		int[][] tiles = new int[n][n];
//		for (int i = 0; i < n; i++)
//			for (int j = 0; j < n; j++)
//				tiles[i][j] = in.readInt();
//		Board initial = new Board(tiles);
//
//		// solve the puzzle
		Solver solver = new Solver(b);

		// print solution to standard output
		if (!solver.isSolvable())
			StdOut.println("No solution possible");
		else {
			StdOut.println("Minimum number of moves = " + solver.moves());
			for (Board board : solver.solution())
				StdOut.println(board);
//		}
		}

	}
}
