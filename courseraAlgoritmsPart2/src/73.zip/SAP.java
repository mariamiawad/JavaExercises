
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import edu.princeton.cs.algs4.BreadthFirstDirectedPaths;
import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;

public class SAP {
	private final Digraph digraph;
	private Map<HashSet<Integer>, int[]> map;

	public SAP(Digraph G) {
		if (G == null) {
			throw new IllegalArgumentException();
		}
		this.digraph = G;
		this.map = new HashMap<>();
	}

	public int length(int v, int w) {

		sap(v, w);
		HashSet<Integer> key = new HashSet<>();
		key.add(v);
		key.add(w);
		int[] value = map.get(key);
		return value[0];
	}

	public int ancestor(int v, int w) {
		sap(v, w);
		HashSet<Integer> key = new HashSet<>();
		key.add(v);
		key.add(w);
		int[] value = map.get(key);
		return value[1];
	}

	public int length(Iterable<Integer> v, Iterable<Integer> w) {
		return sap(v, w)[0];

	}

	public int ancestor(Iterable<Integer> v, Iterable<Integer> w) {
		return sap(v, w)[1];
	}

	private void sap(int v, int w) {
//		if (v == 0 || w == 0) {
//			throw new IllegalArgumentException();
//		}
		HashSet<Integer> key = new HashSet<>();
		key.add(v);
		key.add(w);

		// check cache
		if (map.containsKey(key))
			return;

		// bfs from v
		BreadthFirstDirectedPaths vPath = new BreadthFirstDirectedPaths(digraph, v);

		// bfs from w
		BreadthFirstDirectedPaths wPath = new BreadthFirstDirectedPaths(digraph, w);

		int distance = Integer.MAX_VALUE;
		int ancestor = -2;
		// loop through each vertex and find the minimal ancestor length one
		for (int vertex = 0; vertex < digraph.V(); vertex++) {
			if (vPath.hasPathTo(vertex) && vPath.distTo(vertex) < distance && wPath.hasPathTo(vertex)
					&& wPath.distTo(vertex) < distance) {
				int sum = vPath.distTo(vertex) + wPath.distTo(vertex);
				if (distance > sum) {
					distance = sum;
					ancestor = vertex;
				}
			}
		}

		if (distance == Integer.MAX_VALUE) {
			// which means no such path
			distance = -1;
			ancestor = -1;
		}

		int[] value = new int[] { distance, ancestor };
		map.put(key, value);
	}

	private int[] sap(Iterable<Integer> v, Iterable<Integer> w) {
		if (v == null || w == null) {
			throw new IllegalArgumentException();
		}
//        HashSet<Integer> key = new HashSet<>();
//        key.add(v);
//        key.add(w);

//        // check cache
//        if (map.containsKey(key))
//            return;

		// bfs from v
		BreadthFirstDirectedPaths vPath = new BreadthFirstDirectedPaths(digraph, v);

		// bfs from w
		BreadthFirstDirectedPaths wPath = new BreadthFirstDirectedPaths(digraph, w);

		int distance = Integer.MAX_VALUE;
		int ancestor = -2;
		// loop through each vertex and find the minimal ancestor length one
		for (int vertex = 0; vertex < digraph.V(); vertex++) {
			if (vPath.hasPathTo(vertex) && vPath.distTo(vertex) < distance && wPath.hasPathTo(vertex)
					&& wPath.distTo(vertex) < distance) {
				int sum = vPath.distTo(vertex) + wPath.distTo(vertex);
				if (distance > sum) {
					distance = sum;
					ancestor = vertex;
				}
			}
		}

		if (distance == Integer.MAX_VALUE) {
			// which means no such path
			distance = -1;
			ancestor = -1;
		}

		int[] value = new int[] { distance, ancestor };
//        map.put(key, value);
		return value;
	}


//	// do unit testing of this class
	public static void main(String[] args) {
		In in = new In(args[0]);
		Digraph G = new Digraph(in);
		SAP sap = new SAP(G);
		while (!StdIn.isEmpty()) {
			int v = StdIn.readInt();
			int w = StdIn.readInt();
			int length = sap.length(v, w);
			int ancestor = sap.ancestor(v, w);
			StdOut.printf("length = %d, ancestor = %d\n", length, ancestor);
		}
	}
}
