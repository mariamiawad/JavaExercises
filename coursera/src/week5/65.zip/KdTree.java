
import java.util.Scanner;

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.Point2D;
import edu.princeton.cs.algs4.RectHV;

public class KdTree {
	private int size;
	private Node root;

	private class Node {
		private Point2D key; // sorted by key
		private Double val; // associated data
		private Node left, right; // left and right subtrees
		private int size; // number of nodes in subtree

		public Node(Point2D key, Double val, int size) {
			this.key = key;
			this.val = val;
			this.size = size;
		}

		private void draw() {
			if (left != null) {
				left.draw();
			}
			key.draw();
			if (right != null) {
				right.draw();
			}
		}
	}

	public KdTree() {
		// construct an empty set of points
		root = null;

	}

	public boolean isEmpty() {
		// is the set empty?
		return size() == 0;
	}

	public void insert(Point2D key) {
		if (key == null)
			throw new IllegalArgumentException("calls put() with a null key");
		if (Double.valueOf(key.x()) == null) {
			delete(key);
			return;
		}
		root = put(root, key, key.x());
	}

	private Node put(Node x, Point2D key, Double val) {
		if (x == null)
			return new Node(key, val, 1);
		int cmp = key.compareTo(x.key);
		if (cmp < 0)
			x.left = put(x.left, key, val);
		else if (cmp > 0)
			x.right = put(x.right, key, val);
		else
			x.val = val;
		x.size = 1 + size(x.left) + size(x.right);
		return x;
	}

	private void delete(Point2D key) {
		if (key == null)
			throw new IllegalArgumentException("calls delete() with a null key");
		root = delete(root, key);
	}

	private Node delete(Node x, Point2D key) {
		if (x == null)
			return null;

		int cmp = key.compareTo(x.key);
		if (cmp < 0)
			x.left = delete(x.left, key);
		else if (cmp > 0)
			x.right = delete(x.right, key);
		else {
			if (x.right == null)
				return x.left;
			if (x.left == null)
				return x.right;
			Node t = x;
			x = min(t.right);
			x.right = deleteMin(t.right);
			x.left = t.left;
		}
		x.size = size(x.left) + size(x.right) + 1;
		return x;
	}

	private Node deleteMin(Node x) {
		if (x.left == null)
			return x.right;
		x.left = deleteMin(x.left);
		x.size = size(x.left) + size(x.right) + 1;
		return x;
	}

	private Node min(Node x) {
		if (x.left == null)
			return x;
		else
			return min(x.left);
	}

	public int size() {
		return size(root);
	}

	// return number of key-value pairs in BST rooted at x
	private int size(Node x) {
		if (x == null)
			return 0;
		else
			return x.size;
	}

	public boolean contains(Point2D key) {
		if (key == null)
			throw new IllegalArgumentException("argument to contains() is null");
		return get(key) != null;
	}

	private Double get(Point2D key) {
		return get(root, key);
	}

	private Double get(Node x, Point2D key) {
		if (key == null)
			throw new IllegalArgumentException("calls get() with a null key");
		if (x == null)
			return null;
		int cmp = key.compareTo(x.key);
		if (cmp < 0)
			return get(x.left, key);
		else if (cmp > 0)
			return get(x.right, key);
		else
			return x.val;
	}

	public void draw() {
		if (!isEmpty()) {
			root.draw();
		}
	}

	public Iterable<Point2D> range(RectHV rect) {
		// all points that are inside the rectangle (or on the boundary)
		if (rect == null || root == null) {
			return null;
		}
		MinPQ<Point2D> queue = new MinPQ<>();
		return range(root, rect, queue);
	}

	private Iterable<Point2D> range(Node point2d, RectHV rect, MinPQ<Point2D> queue) {
		// all points that are inside the rectangle (or on the boundary)

		if (rect.contains(point2d.key)) {
			queue.insert(point2d.key);
		}

		if (point2d.left != null) {
			range(point2d.left, rect, queue);
		} else if (point2d.right != null) {
			range(point2d.right, rect, queue);

		}
		return queue;
	}

	public Point2D nearest(Point2D p) {
		// a nearest neighbor in the set to point p; null if the set is empty
		if (p == null) {
			throw new IllegalArgumentException();
		}
		if (isEmpty()) {
			return null;
		}
		return nearest(root, p);

	}

	private Point2D nearest(Node node, Point2D p) {
		// a nearest neighbor in the set to point p; null if the set is empty
		if (p == null) {
			throw new IllegalArgumentException();
		}
		if (isEmpty()) {
			return null;
		}
		Node minNode = node;
		if (node.right != null) {
			nearest(node.right, p);
		}
		if (node.left != null) {
			nearest(node.left, p);
		}
		return minNode.key;
	}

	public static void main(String[] args) {
		In in = new In("file:///C:/Users/maria/eclipse-workspace/coursera/input/week5/input10.txt");
		Iterable<Point2D> iterable = null;
		KdTree tree = new KdTree();
		while (!in.isEmpty()) {
			tree.insert(new Point2D(in.readDouble(), in.readDouble()));
		}
		iterable = tree.range(new RectHV(0.127, 0.634,0.186, 0.99));
		if (iterable != null) {
			while (iterable.iterator().hasNext()) {
				System.out.println(iterable.iterator().next());
			}

		}
//		Scanner scanner = new Scanner(System.in);
//		KdTree  kdTree  =new KdTree();
//		String [] strings = new String[10];
//		
//		RectHV rectHV = new RectHV(0.127, 0.634,0.186, 0.99);
//		for (int i = 0; i < strings.length; i++) {
//			strings[i] = scanner.next();
//			
//			kdTree.insert(new Point2D(scanner.nextDouble(), scanner.nextDouble()));
//			
//		}
//		Iterable<Point2D> iterable = kdTree.range(rectHV);
//		while (iterable.iterator().hasNext()) {
//			System.out.println(iterable.iterator().next());
//			
//		}
		
	}
}